import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admission-update',
  templateUrl: './admission-update.component.html',
  styleUrls: ['./admission-update.component.css']
})
export class AdmissionUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
