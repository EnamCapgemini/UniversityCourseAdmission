import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admission-create',
  templateUrl: './admission-create.component.html',
  styleUrls: ['./admission-create.component.css']
})
export class AdmissionCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
