import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'applicant-create',
  templateUrl: './applicant-create.component.html',
  styleUrls: ['./applicant-create.component.css']
})
export class ApplicantCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
