export interface AdmissionCommiteeMember {
    admissionCommiteeMemberId: number;
    admissionCommiteeMemberName: string;
    admissionCommiteeMemberContact: string;

}