export interface loginCredentials{

    username: String;
    password: String;

}