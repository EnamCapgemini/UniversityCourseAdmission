export interface Course{
    courseId:number;
    courseName:string;
    courseDuration:string;
    courseStartDate:Date;
    courseEndDate:Date;
    courseFees:string;
}