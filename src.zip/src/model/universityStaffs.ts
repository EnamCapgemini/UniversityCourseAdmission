export interface UniversityStaffs{
    staffId:number,
    username:string,
    password:string,
    role:string,
    courses:string[]
}