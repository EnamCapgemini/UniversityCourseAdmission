export interface Admission{
    admissionId:number;
    courseId:number;
    admissionDate:Date;
    status:string;
}